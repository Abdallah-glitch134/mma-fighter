# MMA Fighter — GitHub Actions APK Build

This package is the Android wrapper source for MMA Fighter 2.0.1.

Important: GitHub does not automatically extract ZIP uploads. Upload this ZIP to the repository, then use the workflow supplied separately in the project instructions.
