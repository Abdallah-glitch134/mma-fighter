# MMA Fighter 2.0.1 — Android Build

The web app is packaged for Capacitor 7.4.3.

## Build
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug

APK output: android/app/build/outputs/apk/debug/app-debug.apk

This environment has Node.js and JDK but does not provide Android SDK/Gradle, and outbound npm installation is unavailable/time-limited. Therefore this package is Android-build-ready, not a compiled APK.
