# MMA Fighter 2.0.1 — GitHub Actions APK Build

This package contains the Android-ready Capacitor wrapper and a GitHub Actions workflow.

## Build automatically

1. Create an empty GitHub repository.
2. Upload **all contents of this folder** to the repository root (including `.github/workflows/build-apk.yml`).
3. Push to the `main` branch, or open **Actions → Build MMA Fighter APK → Run workflow**.
4. The workflow installs Node 22, Java 17, Android SDK, Capacitor Android, creates the native `android/` project, syncs `www/`, and runs `assembleDebug`.
5. After the workflow succeeds, open the workflow run and download the artifact named **mma-fighter-debug-apk**.

The generated file is an installable debug APK at:
`android/app/build/outputs/apk/debug/app-debug.apk`

No Supabase service-role/secret key is stored in this Android package. The app uses the public publishable client configuration already present in `www/index.html`.
